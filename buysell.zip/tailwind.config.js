module.exports = {
  important: true,
  purge: [],
  theme: {
    extend: {},
  },
  variants: {},
  plugins: [],
}
