

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">Faq</h1>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
    <div class="row">
        <div class="col-md-12">
            <!--card -->
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <?php echo e($error); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php echo $__env->make('messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card">
                <div class="card-header">
                  <h3 class="card-title">List of FAQ</h3>
                  <div class="card-tools">
                      <a href="#"  class="btn btn-primary btn-sm" data-toggle="modal" data-target="#newFAQ"><i class="fa fa-plus" aria-hidden="true"></i> Create New</a>
                  </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body table-responsive p-0">
                  <table class="table table-hover text-nowrap">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Created At</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td> <?php echo e($faq->id); ?> </td>
                        <td> <?php echo e($faq->title); ?> </td>
                        <td> <?php echo e($faq->description); ?> </td>
                        <td> <?php echo e($faq->created_at); ?> </td>
                        <td>
                          <?php if($faq->status == 1): ?>
                              <?php echo e($status = 'Active'); ?>

                          <?php else: ?> 
                              <?php echo e($status = 'Inactive'); ?>

                          <?php endif; ?>
                          
                        </td>
                        <td>
                          <div class="btn-group" role="group" aria-label="Basic example">
                              <a href="<?php echo e(route('faq.edit', $faq->id)); ?>" class="btn btn-sm btn-primary">
                                <i class="far fa-edit"></i>
                                Edit
                              </a>
                              
                              <a href="javascript:void(0)" onclick="$(this).parent().find('form').submit() " class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i> Delete</a>
                              <form class="" action="<?php echo e(route('faq.destroy', $faq->id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                              </form>
                          </div>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.card-body -->
            </div>
              <!-- /.card -->
        </div>
        <form action="<?php echo e(route('faq.store')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <?php echo $__env->make('admin.faq.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script>
    $('.toast').toast('show');
    // document.querySelector('.toast').toast('show');
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\exchange\resources\views/admin/faq/index.blade.php ENDPATH**/ ?>