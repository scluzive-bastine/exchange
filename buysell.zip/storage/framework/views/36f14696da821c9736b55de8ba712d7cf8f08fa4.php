;

<?php $__env->startSection('content'); ?>
    
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8">
                <div class="container">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="main__post--container px-4 py-10 mb-4 bg-white shadow-lg">
                            <div class="post--header text-center mb-4">
                                <h5 class="mb-3 font-bold text-teal-500 text-uppercase"> <?php echo e($post->tags->tag); ?> </h5>
                                <a href="<?php echo e(route('posts.show', $post->id)); ?>">
                                    <h1 class="mt-2 font-weight-bold text-gray-600 mb-3" style="font-size: 1.8rem"> <?php echo e($post->title); ?> </h1>
                                </a>
                                <hr class="mb-1 w-32 ml-auto mr-auto">
                                <small class="mt-4 font-bold text-gray-500"> <?php echo e(\Carbon\Carbon::parse($post->created_at)->format("F j, Y, g:i a")); ?> </small>
                                <hr class="mt-1 w-32 ml-auto mr-auto">
                            </div>
                            <div class="post__image--container">
                                <img src="/images/<?php echo e($post->image); ?>" class="img-fluid" alt="post image" style="max-height: 500px; width: 720px;">
                            </div>
                            <div class="post__slug--content mt-4 py-2" data-maxlength="400" style="border-bottom: 1px dashed #ddd;">
                                <p class="text-gray-700 font-sans text-wrap" id="textContent" style="font-size: 1rem;">
                                    <?php
                                        $link = route('posts.show', $post->id);
                                        $content = Str::limit($post->content, 300, "..<br> <a href='$link' class='btn btn-primary btn-sm mt-3'>Continue Reading</a>")
                                    ?>
                                    <?php echo html_entity_decode($content); ?>

                                    
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                </div>
            </div>
            <?php echo $__env->make('news.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript">
        var content = document.querySelector('#textContent').textContent;
        console.log(content);
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\exchange\resources\views/news/index.blade.php ENDPATH**/ ?>