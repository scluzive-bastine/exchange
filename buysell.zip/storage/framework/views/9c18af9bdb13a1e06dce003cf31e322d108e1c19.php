<div class="col-md-4">
    <div class="news__sidebar--post px-4 py-4 shadow-lg bg-white">
        <div class="popular__posts-container mb-4">
            <div class="sidebar--header mb-3">
                <h1 class="text-uppercase text-gray-800 font-weight-bold">Popular Post</h1>
            </div>
            <div class="sidebar--image mb-3">
                <img src=" <?php echo e(asset('/images/post-demo.png')); ?> " class="img-fluid" alt="Popular post image">
            </div>
            <div class="sidebar__slug--text">
                <h1 class="text-gray-800 font-medium">YOU WOULD NEVER THINK BLOCKCHAIN IS USED FOR THIS</h1>
                <small>
                    May 29, 2020
                </small>
            </div>
            <hr class="mt-3">
        </div>
        <div class="popular__posts-container mb-4">
            <div class="sidebar--header mb-3">
                <h1 class="text-uppercase text-gray-800 font-weight-bold">Popular Post</h1>
            </div>
            <div class="sidebar--image mb-3">
                <img src=" <?php echo e(asset('/images/post-demo.png')); ?> " class="img-fluid" alt="Popular post image">
            </div>
            <div class="sidebar__slug--text">
                <h1 class="text-gray-800 font-medium">YOU WOULD NEVER THINK BLOCKCHAIN IS USED FOR THIS</h1>
                <small>
                    May 29, 2020
                </small>
            </div>
            <hr class="mt-3">
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\exchange\resources\views/news/sidebar.blade.php ENDPATH**/ ?>