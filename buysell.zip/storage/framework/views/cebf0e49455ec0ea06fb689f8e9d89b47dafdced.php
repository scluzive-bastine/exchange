

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="about-bg lg:pl-24 lg:pr-24 mt-10">
        <h2 class="text-center text-white font-bold text-4xl">About us</h2>
        <p class="text-center text-center font-normal text-2xl sm:text-gray-800 lg:text-gray-200 ">
            Buy-Sell is a Platform that are interested in giving you the best experience in cryptocurrency exchange
        </p>
    </div>
    <div class="mb-4 mt-20 py-4 px-4 bg-white rounded-lg shadow-lg">
        <div class="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2 gap-4">
            <div class="mt-2">
                <img src="images/abt.svg" class="img-fluid" alt="">
            </div>
            <div class="mt-2">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora reiciendis, dolorem fugit expedita, q
                    uos quisquam similique officia, 
                    ullam numquam ratione doloremque quis repellat. Mollitia neque quos deserunt commodi possimus expedita!
                </p>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\exchange\resources\views/exchange/about-us.blade.php ENDPATH**/ ?>