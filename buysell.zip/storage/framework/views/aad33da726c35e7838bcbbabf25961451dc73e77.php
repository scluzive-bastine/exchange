

<?php $__env->startSection('content'); ?>

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">About us</h1>
            </div><!-- /.col -->
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo e($error); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php echo $__env->make('messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="create__about-us--btn card-header">
    <div class="card-tools">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <?php if($data->exists()): ?>
            <a href="<?php echo e(route('about-us.edit', $data->id)); ?>" class="btn btn-primary btn-sm">
                <i class="fa fa-plus"></i>
                Edit About us Content
            </a> 
            <?php else: ?>
            <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#createAboutUs">
                <i class="fa fa-plus"></i>
                Create About us Content
            </button>   
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="container">
    <div class="ad--about__us--header px-2 py-2 bg-white rounded shadow mt-4">
        <div class="ab-title py-2 px-2 rounded-lg shadow-lg bg-teal-700 text-white w-32 text-center" style="margin-top: -1.5rem;">
            <h5 class="uppercase font-semibold mb-0">Title</h5>
        </div>
        <h5 class="text-teal-700 mt-3"> <?php echo e($data->title); ?> </h5>
    </div>
    <div class="ad--about__us--description px-2 py-2 bg-white rounded shadow mt-4">
        <div class="ab-title py-2 px-2 rounded-lg shadow-lg bg-teal-700 text-white w-32 text-center mb-3" style="margin-top: -1.5rem;">
            <h6 class="uppercase font-semibold mb-0">Content</h6>
        </div>
        <p class="px-2">
            <?php echo e($data->content); ?>

        </p>
    </div>
</div>

<form action="<?php echo e(route('about-us.store')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <?php echo $__env->make('admin.about.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  <script>
    $('.toast').toast('show');
    // document.querySelector('.toast').toast('show');
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\exchange\resources\views/admin/about/index.blade.php ENDPATH**/ ?>