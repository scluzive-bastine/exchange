<?php if($message = Session::get('success')): ?>
<div class="toast ml-auto" role="alert" aria-live="assertive" aria-atomic="true" data-autohide="true" data-delay="2000">
    <div class="toast-header">
      <i class="far fa-check-circle mr-1 text-green-500" style="color: #009900; font-size: 1.5rem"></i>
      <strong class="mr-auto" style="font-size: 1.1rem; color: #009900;">Successful</strong>
      
      <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="toast-body">
      <?php echo e($message); ?>

    </div>
</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\exchange\resources\views/messages.blade.php ENDPATH**/ ?>