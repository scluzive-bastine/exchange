

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="faq-bg lg:pl-24 lg:pr-24 mt-10 sm:text-gray-800">
        <h2 class="text-center lg:text-white sm:text-blue-700 font-bold text-4xl">FAQ</h2>
        <p class="text-center text-center font-normal text-2xl sm:text-gray-800 lg:text-gray-200 ">
            Buy-Sell is a Platform that are interested in giving you the best experience in cryptocurrency exchange <br>
            Frequently asked questions
        </p>
    </div>
    <div class="faq lg:mt-32 sm:mt-4 mb-5 lg:mb-10">        
        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="accordion mt-2" id="accordionExample">
            <div class="card shadow" style="border-radius: 30px">
              <div class="card-header bg-white" id="headingOne">
                <h2 class="mb-0">
                  <div class="flex px-4 py-2" type="button" data-toggle="collapse" data-target="#faq<?php echo e($faq->id); ?>" aria-expanded="true" aria-controls="collapseOne">
                    <span class="ml-1 text-md uppercase text-blue-700 faq__header font-bold"> <?php echo e($faq->title); ?> </span>
                    <span class="ml-auto text-lg">  <i class="fas fa-chevron-circle-down text-blue-800 transition-all duration-150"></i></span>
                    
                  </div>
                </h2>
              </div>
          
              <div id="faq<?php echo e($faq->id); ?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                <div class="card-body">
                  <?php echo e($faq->description); ?>

                </div>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
      function btnClick() {
        let btn = document.querySelector('.faq__header').parentElement.addEventListener('click', function() {
            document.querySelector('.fa-chevron-circle-down').classList.toggle('faq__icon--dropdown')
        });
      }
      btnClick()
      // for(var i = 0; i <= 5; i++) {
      //   btnClick()
      // }
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\exchange\resources\views/exchange/faq.blade.php ENDPATH**/ ?>