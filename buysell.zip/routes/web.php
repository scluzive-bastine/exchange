<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('exchange.index');})->name('home'); 

Route::get('/', 'UserController@index')->name('home');
Route::get('/faq', 'UserController@faq')->name('user.faq');
Route::get('/about-us', 'UserController@aboutUs')->name('user.about');
Route::get('/markets', 'UserController@markets')->name('user.markets');
Route::get('/market/{page?}', 'UserController@marketsPaginate')->name('user.marketsPaginate');
Route::get('/news', 'UserController@news')->name('posts.index');
Route::get('/news/{news?}', 'UserController@showNews')->name('posts.show');

Route::post('/exchange', 'UserController@exchangeConfirmDetails')->name('exchange.confirm_details');
Route::post('/confirm', 'UserController@exchangeConfirm')->name('exchange.confirm');
Route::post('/success', 'UserController@exchangeSuccessful')->name('exchange.success');
Route::get('/successful-exchange/{id?}', 'UserController@exchangeCompleted')->name('exchange.completed');

Route::get('/defi-exchange', 'UserController@defiExchange')->name('defi.exchange');
Route::get('/bse-token', 'UserController@bseToken')->name('defi.token');
Route::get('/staking', 'UserController@staking')->name('defi.staking');
Route::get('/staking-dashboard', 'UserController@stakingDashboard')->name('staking.dashboard');



Route::get('/markets/{coin}', 'UserController@marketcoin')->name('user.marketcoin');



Route::group(['prefix' => 'sdfgydjtydreetsr'], function () {
    Auth::routes([
        'register' => false
    ]);
    Route::post('login', 'LoginController@login')->name('admin.login');
    Route::group(['middleware' => 'auth','admin'], function () {
        Route::get('/home', 'LoginController@admin')->name('admin.index');
        Route::resource('faq', 'Admin\FaqController');
        Route::resource('about-us', 'Admin\AboutUsController');
        Route::resource('tags', 'Admin\TagsController');
        Route::resource('news', 'Admin\NewsController');

    });
});


// waigf@d3v3lop3r
