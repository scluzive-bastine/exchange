<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BSE DeFi Token</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="{{ asset('js/flickity.js') }}"></script>
    <script src="{{ asset('js/script.js') }}"></script>

    {{-- Favicon --}}
    <link rel="shortcut icon" type="image/png" href=" {{ asset('/images/buysell-logo.png') }} ">


    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('css/main.css')}}">
    {{-- <link rel="stylesheet" href="{{asset('css/custom.css')}}"> --}}
    <link rel="stylesheet" href="{{asset('css/bse.css')}}">
    <link rel="stylesheet" href="{{asset('css/flickity.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.0-2/css/all.min.css">
</head>
<body class="font-sans text-white" style="background: #061831;">
    <nav class="navbar navbar-expand-sm navbar-light">
        <a class="navbar-brand" href=" {{route('home')}} ">
            <img src="/images/bs-logo-circle.png" width="50" height="50" alt="">
        </a>
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
            </ul>
            <ul class="navbar-nav font-bold lg:text-gray-800">
                <li class="nav-item">
                  <button class="btn btn-primary px-4" style="border-radius: 50px;background: #2c5282!important;border-color: #2c5282!important;">Connect Wallet</button>
                </li>

            </ul>
        </div>
    </nav>
    
<div class="container mt-10 mb-5" id="app">
    <div class="row">
        <div class="col-12 col-md-4 sm:px-12 lg:px-2 mb-2">
            <div class="staking__sidebar--container bg-white rounded shadow px-2 py-2" style="height: 400px">
                <div class="asset--address bg-gray-200 px-2 py-1 overflow-hidden w-48 shadow-sm" style="border-radius: 50px">
                    <span class="text-gray-800 flex"> <i class="fas fa-copy mr-2 mt-1"></i> 0x957D906AEB375833E20cF1cf92Fa07AD37eEDe94</span>
                </div>
                <ul class="nav flex-column mt-3">
                    <li class="nav-item stake-nav stake-active text-white rounded-lg">
                      <a class="nav-link asset-staking" href="#">
                        <i class="fas fa-coins ml-2 mr-2 text-2xl"></i>
                          Assets Staking
                        </a>
                    </li>
                    <li class="nav-item stake-nav swap-bse rounded-lg text-blue-800 mt-1">
                        <a class="nav-link" href="#">
                          <i class="fas fa-exchange-alt ml-2 mr-2 text-2xl"></i>
                           Swap BSE
                        </a>
                    </li>
                    <li class="nav-item stake-nav rounded-lg text-blue-800 mt-1">
                        <a class="nav-link" href="#">
                            <i class="fas fa-poll ml-2 mr-2 text-2xl"></i>
                            Pooled Staking
                          </a>
                    </li>
                    <li class="nav-item stake-nav rounded-lg text-blue-800 mt-1">
                        <a class="nav-link" href="#">
                          <i class="fas fa-money-check-alt ml-2 mr-2 text-2xl"></i>
                           Earn Interest
                        </a>
                    </li>
                    <li class="nav-item stake-nav rounded-lg text-blue-800 mt-1">
                        <a class="nav-link" href="#">
                          <i class="fas fa-hand-holding-usd ml-2 mr-2 text-2xl"></i>
                           Borrow
                        </a>
                    </li>
                    <li class="nav-item stake-nav rounded-lg text-blue-800 mt-1">
                        <a class="nav-link" href="#">
                          <i class="fas fa-globe-americas ml-2 mr-2 text-2xl"></i>
                           Governance
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="col-12 col-md-8">
            <div class="section__assets--staking">
                <div class="staking__header-dashboard px-4 py-2 rounded shadow bg-gray-200">
                    <div class="flex">
                        <div class="stake--header">
                            <h1 class="font-bold uppercase text-blue-800">BuySell Staking</h1>
                            <p class="text-gray-800">Stake and Earn you trusted crypto assets and receive BSE tokens</p>
                        </div>

                        <div class="ml-auto">
                            <button type="button" class="btn btn-outline-primary btn__start--swaping"> <i class="fas fa-handshake"></i> Start Staking</button>
                        </div>
                    </div>
                    {{-- <div class="container"> --}}
                        <div class="row mt-4">
                            <div class="col-md-3 mb-2">
                                <div class="staking__contents--header px-2 py-6 text-center rounded shadow" style="background: #9b2c2c;">
                                    <h1 class="font-bold uppercase">Total Assets Staked</h1>
                                    <span class="text-2xl">5</span> <br>
                                    <small>-</small>
                                </div>
                            </div>
                            <div class="col-md-3 mb-2">
                                <div class="staking__contents--header px-2 py-6 text-center rounded shadow" style="background: #4a5568">
                                    <h1 class="font-bold uppercase">Total Staked</h1>
                                    <span class="text-2xl">100.000 BSE</span>
                                    <small>$25.000 USDC</small>
                                </div>
                            </div>
                            <div class="col-md-3 mb-2">
                                <div class="staking__contents--header px-2 py-6 text-center rounded shadow" style="background: #1a202c">
                                    <h1 class="font-bold uppercase">Total Rewards</h1>
                                    <span class="text-2xl">101.000 BSE</span>
                                    <small>$25.000 USDC</small>
                                </div>
                            </div>
                            <div class="col-md-3 mb-2">
                                <div class="staking__contents--header px-2 py-6 text-center rounded shadow" style="background: #f6ad55">
                                    <h1 class="font-bold uppercase">Total Avg. Returns</h1>
                                    <span class="text-2xl">N/A</span> <br>
                                    <small>N/A</small>
                                </div>
                            </div>
                        </div>
                    {{-- </div> --}}
                </div>
                <div class="container mt-4">
                    <h1 class="font-bold text-white uppercase">Select Asset to stake</h1>
                    <hr style="    width: 100px;
                    color: #fff;
                    background: #fff;
                    margin-top: 3px;
                    border-top-width: 3px!important;;">
    
                    <div class="staking__assets--container">
                        <div class="row">
                            <div class="col-12 col-md-4">
                                <div class="staking--assets mt-4 px-4 py-4 text-center bg-white rounded shadow-lg">
                                    <img src="/images/160408.png" class="img-fluid ml-auto mr-auto" alt="">
                                    <span class="text-blue-800 font-bold uppercase mt-2">Cosmos</span>
                                    <p class="mt-2">
                                        <a href="#" class="btn btn-outline-primary btn-stake px-6" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius: 50px">Stake Now</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div class="staking--assets mt-4 px-4 py-4 text-center bg-white rounded shadow-lg">
                                    <img src="/images/160449.png" class="img-fluid ml-auto mr-auto" alt="">
                                    <span class="text-blue-800 font-bold uppercase mt-2">Tezos</span>
                                    <p class="mt-2">
                                        <a href="#" class="btn btn-outline-primary btn-stake px-6" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius: 50px">Stake Now</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div class="staking--assets mt-4 px-4 py-4 text-center bg-white rounded shadow-lg">
                                    <img src="/images/160549.png" class="img-fluid ml-auto mr-auto" alt="">
                                    <span class="text-blue-800 font-bold uppercase mt-2">Neo</span>
                                    <p class="mt-2">
                                        <a href="#" class="btn btn-outline-primary btn-stake px-6" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius: 50px">Stake Now</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        {{--  --}}
                        <div class="row mt-2">
                            <div class="col-12 col-md-4">
                                <div class="staking--assets mt-4 px-4 py-4 text-center bg-white rounded shadow-lg">
                                    <img src="/images/160612.png" class="img-fluid ml-auto mr-auto" alt="">
                                    <span class="text-blue-800 font-bold uppercase mt-2">Ontology</span>
                                    <p class="mt-2">
                                        <a href="#" class="btn btn-outline-primary btn-stake px-6" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius: 50px">Stake Now</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div class="staking--assets mt-4 px-4 py-4 text-center bg-white rounded shadow-lg">
                                    <img src="/images/160755.png" class="img-fluid ml-auto mr-auto" alt="">
                                    <span class="text-blue-800 font-bold uppercase mt-2">Komodo</span>
                                    <p class="mt-2">
                                        <a href="#" class="btn btn-outline-primary btn-stake px-6" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius: 50px">Stake Now</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div class="staking--assets mt-4 px-4 py-4 text-center bg-white rounded shadow-lg">
                                    <img src="/images/160847.png" class="img-fluid ml-auto mr-auto" alt="">
                                    <span class="text-blue-800 font-bold uppercase mt-2">Tron</span>
                                    <p class="mt-2">
                                        <a href="#" class="btn btn-outline-primary btn-stake px-6" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius: 50px">Stake Now</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                        {{--  --}}
                        <div class="row mt-2">
                            <div class="col-12 col-md-4">
                                <div class="staking--assets mt-4 px-4 py-4 text-center bg-white rounded shadow-lg">
                                    <img src="/images/160915.png" class="img-fluid ml-auto mr-auto" alt="">
                                    <span class="text-blue-800 font-bold uppercase mt-2">Algorand</span>
                                    <p class="mt-2">
                                        <a href="#" class="btn btn-outline-primary btn-stake px-6" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius: 50px">Stake Now</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div class="staking--assets mt-4 px-4 py-4 text-center bg-white rounded shadow-lg">
                                    <img src="/images/160951.png" class="img-fluid ml-auto mr-auto" alt="">
                                    <span class="text-blue-800 font-bold uppercase mt-2">Vechain</span>
                                    <p class="mt-2">
                                        <a href="#" class="btn btn-outline-primary btn-stake px-6" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius: 50px">Stake Now</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div class="staking--assets mt-4 px-4 py-4 text-center bg-white rounded shadow-lg">
                                    <img src="/images/161032.png" class="img-fluid ml-auto mr-auto" alt="">
                                    <span class="text-blue-800 font-bold uppercase mt-2">Band Protocol</span>
                                    <p class="mt-2">
                                        <a href="#" class="btn btn-outline-primary btn-stake px-6" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius: 50px">Stake Now</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="section__assets--swap bg-white text-gray-800 shadow-2xl" style="display: none">
                <div class="card">
                    <div class="card-header">
                        <h1 class="font-bold text-blue-800 uppercase">Atomic Swap</h1>
                    </div>
                    <div class="card-body">
                        <div class="swap__container">
                            <div class="row">
                                <div class="col-12 col-md-6">
                                    <div class="swap__send--container px-2 py-2 shadow">
                                        <div class="flex">
                                            <label for="">Amount</label>
                                            <span class="ml-auto text-green-500 font-bold">Max</span>
                                        </div>
                                        <div class="flex">
                                            <div class="swap__send--input" style="width: 70%">
                                                <input type="text" class="form-control swap-input text-right" placeholder="0">
                                            </div>
                                            <div class="flex ml-2 bg-gray-200 rounded px-2 py-2" style="width: 30%">
                                                <span class="uppercase mr-2">BSE</span>
                                                <span class="ml-auto">
                                                    <i class="fas fa-caret-down"></i>
                                                </span>
                                            </div>
                                        </div>
                                        <small class="ml-auto">-$0.00</small>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="swap__receive--container px-2 py-2">
                                        <div class="flex">
                                            <label for="">Amount to receive</label>
                                            {{-- <span class="ml-auto text-green-500 font-bold">Max</span> --}}
                                        </div>
                                        <div class="flex">
                                            <div class="swap__send--input" style="width: 70%">
                                                <input type="text" class="form-control swap-input text-right" placeholder="0">
                                            </div>
                                            <div class="flex ml-2 bg-gray-200 rounded px-2 py-2" style="width: 30%">
                                                <span class="uppercase mr-2">LID</span>
                                                {{-- <span class="ml-auto">
                                                    <i class="fas fa-caret-down"></i>
                                                </span> --}}
                                            </div>
                                        </div>
                                        <div class="flex">
                                            <small class="ml-auto font-bold mt-2">1 LID = N/A ETH</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer text-muted">
                        <div class="flex">
                            <div class="ml-auto">
                                <button class="btn btn-primary px-4" style="background: #2c5282!important;border-color: #2c5282!important;">Swap</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title text-blue-800 uppercase font-bold" id="exampleModalLabel">Stake Cosmos</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="stake__coins--modal">
            <ul class="list-group">
                <li class="list-group-item">
                    <div class="flex">
                        <h1 class="font-bold text-blue-800">Balance</h1>
                        <span class="ml-auto font-black text-blue-900">500</span>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="flex">
                        <h1 class="font-bold text-blue-800">Staked</h1>
                        <span class="ml-auto font-black text-blue-900">1</span>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="flex">
                        <h1 class="font-bold text-blue-800">Unstaked</h1>
                        <span class="ml-auto font-black text-blue-900">100 </span>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="flex">
                        <h1 class="font-bold text-blue-800">Earned</h1>
                        <span class="ml-auto font-black text-blue-900">200</span>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="flex">
                        <h1 class="font-bold text-blue-800">BSE Reward</h1>
                        <span class="ml-auto font-black text-blue-900">0 <small>BSE</small> <small class="ml-1 badge-primary rounded px-2 py-1">Claim</small></span>
                    </div>
                </li>
              </ul>
              <div class="flex mt-3">
                  <button class="btn btn-primary px-4" style="border-radius: 50px">Stake</button>
                  <button class="btn btn-danger px-4 ml-2" style="border-radius: 50px">Unstake</button>
              </div>
          </div>
        </div>
        {{-- <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div> --}}
      </div>
    </div>
  </div>
    
</body>
<!-- jQuery -->
<script src="{{asset('js/jquery.min.js')}}"></script>
<!-- jQuery UI 1.11.4 -->
<script src="{{asset('js/jquery-ui.min.js')}}"></script>
@push('scripts')
<script type="text/javascript">
var navitem = $('.nav-item');
navitem.addEventListener('click', function(e) {
    console.log('clicked');
});



 </script>
@endpush
</html>
